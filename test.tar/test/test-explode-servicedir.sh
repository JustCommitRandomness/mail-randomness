#!/bin/sh
envdir=`pwd`/ENV
for dir in
#    explode/*
    explode-net/*
    do
    echo =======================
    echo ==== $dir
    ( cd $dir;
      env -i ETC=$envdir ../../../package/perl/explode-servicedir /usr/bin/printenv )
done
